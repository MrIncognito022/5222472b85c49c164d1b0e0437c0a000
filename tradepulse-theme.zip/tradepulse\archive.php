<?php
/**
 * Archive template.
 *
 * @package TradePulse
 */

get_header();
?>

<main id="primary" class="archive-shell">
	<header class="archive-header">
		<span class="eyebrow"><?php esc_html_e( 'Browse the journal', 'tradepulse' ); ?></span>
		<?php the_archive_title( '<h1 class="page-title">', '</h1>' ); ?>
		<?php the_archive_description( '<div class="archive-description">', '</div>' ); ?>
	</header>

	<?php if ( have_posts() ) : ?>
		<div class="grid grid--two">
			<?php
			while ( have_posts() ) :
				the_post();
				tradepulse_card();
			endwhile;
			?>
		</div>
		<?php the_posts_pagination(); ?>
	<?php else : ?>
		<div class="empty-state">
			<h2><?php esc_html_e( 'Nothing published here yet.', 'tradepulse' ); ?></h2>
			<p><?php esc_html_e( 'Try another topic or search the full archive.', 'tradepulse' ); ?></p>
			<?php get_search_form(); ?>
		</div>
	<?php endif; ?>
</main>

<?php get_footer();
